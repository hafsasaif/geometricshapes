/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricshapes;

/**
 *
 * @author monst
 */
interface Shape {
    
    final double PI = 3.14;
    
    public void UserName(String s);
    public void ShapeName(String s);
    public void summaryPrint();
}
