/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricshapes;

/**
 *
 * @author monst
 */
public abstract class ThreeDimensionShape implements Shape {
    private String uName;
    private String sName;
    
    @Override
     public void UserName(String s)
     {
         this.uName = s;
     }
    @Override
    public void ShapeName(String s)
    {
        this.sName = s;
    }
    @Override
     public void summaryPrint()
    {
        System.out.println("Name: "+uName);
        System.out.println("Shape Name: "+sName);
    }
     
    public abstract double calculateSurfaceArea();
    
    public abstract double calculateVolume();

    public String getuName() {
        return uName;
    }

    public String getsName() {
        return sName;
    }
    
    
}
