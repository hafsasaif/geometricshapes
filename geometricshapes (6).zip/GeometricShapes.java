/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricshapes;

import java.util.Scanner;

/**
 *
 * @author monst
 */
public class GeometricShapes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String category = "";
    Scanner input = new Scanner(System.in);
    do{
    try
    {
        
        System.out.println("Please enter the Category: ");
        System.out.println("1-For 2D Shapes");
        System.out.println("2-For 3D Shapes");
        System.out.println("3-Exit");
        System.out.print("Please enter the option: ");
        category = input.nextLine();
     if(category.equalsIgnoreCase("1"))
    {
        String option="";
        do{
            System.out.println("Please enter the shpae that you want to calculate");
        System.out.println("1-For Circle");
        System.out.println("2-For Square");
        System.out.println("3-For Triangle");
            System.out.println("4-Exit");
            System.out.print("Please enter the option: ");
            option = input.nextLine();
            switch(option)
            {
                case "1":
                    Circle circle = new Circle();
                    break;
                case "2":
                    Square squ = new Square();
                    break;
                case "3":
                     Triangle tri = new Triangle();
                     break;
                default:
                    break;
            }
        }while(!option.equalsIgnoreCase("4") );
        
        
    }else if(category.equalsIgnoreCase("2"))
    {
         String option="";
        do{
            System.out.println("Please enter the shpae that you want to calculate");
        System.out.println("1-For Cube");
        System.out.println("2-For Cylinder");
        System.out.println("3-For Pyramid");
            System.out.println("4-Exit");
            System.out.print("Please enter the option: ");
            option = input.nextLine();
            switch(option)
            {
                case "1":
                    Cube cub = new Cube();
                    break;
                case "2":
                    Cylinder cy = new Cylinder();
                    break;
                case "3":
                     Pyramid pyrmd = new Pyramid();
                     break;
                default:
                    break;
            }
        }while(!option.equalsIgnoreCase("4") );
    }
        
    }catch(Exception e)
    {
        System.out.println("wrong option");
    } 
    }while(!category.equalsIgnoreCase("3"));
    
   
    
    }
    
}
